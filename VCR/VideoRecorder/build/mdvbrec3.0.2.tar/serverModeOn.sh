#!/bin/sh
#sets a marker file to turn on energy mode
cd "$(dirname "$0")"
touch mdvbrec/xmltv/MODE_SERVER

